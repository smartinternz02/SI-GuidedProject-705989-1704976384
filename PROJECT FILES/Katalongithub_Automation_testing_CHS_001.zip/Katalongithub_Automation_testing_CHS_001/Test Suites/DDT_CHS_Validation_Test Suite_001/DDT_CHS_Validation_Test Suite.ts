<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>DDT_CHS_Validation_Test Suite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>a4dd99a5-85e7-421a-a543-10a6842adf91</testSuiteGuid>
   <testCaseLink>
      <guid>d4d237e2-d08d-47a4-831c-9f496946e30c</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Data Driven Testing/DDT_CHS_Validation_Login_Excel</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>4c97fe33-f36c-49f1-8a89-7ef1ebd2e13f</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/CHS_TESTDATA/CHS_TestData_Excel_login</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>4c97fe33-f36c-49f1-8a89-7ef1ebd2e13f</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>username</value>
         <variableId>35d21315-b976-4b03-ab07-0fc61fabcb01</variableId>
      </variableLink>
      <variableLink>
         <testDataLinkId>4c97fe33-f36c-49f1-8a89-7ef1ebd2e13f</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>password</value>
         <variableId>d1857958-201f-461a-bccf-c0b65d1011f7</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
