<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Medicare                               _cb3988</name>
   <tag></tag>
   <elementGuidId>ddc312b4-eaa7-4a99-94c7-41e9f6433c94</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='appointment']/div/div/form/div[3]/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>3b9990a5-ec6c-4af2-a03b-d592d95fdd51</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-sm-4</value>
      <webElementGuid>0a14b9d9-3fc9-4eed-b3a7-fbb212b2e082</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                             Medicare
                        
                        
                             Medicaid
                        
                        
                             None
                        
                    </value>
      <webElementGuid>9f6caa1b-cf07-4299-ad9a-ba53128ce243</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;appointment&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/form[@class=&quot;form-horizontal&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;col-sm-4&quot;]</value>
      <webElementGuid>4ab3f1f0-d945-48da-87c1-d6c903d95f53</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='appointment']/div/div/form/div[3]/div</value>
      <webElementGuid>cac50ec1-e7a3-4abc-b3d9-938da801d529</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div</value>
      <webElementGuid>df4515e2-eb06-4e0e-8c12-8b27cde7e06f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                        
                             Medicare
                        
                        
                             Medicaid
                        
                        
                             None
                        
                    ' or . = '
                        
                             Medicare
                        
                        
                             Medicaid
                        
                        
                             None
                        
                    ')]</value>
      <webElementGuid>9ff5e42f-f65c-41fb-bffd-0c9ea6b2672b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
